import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-_wZywoZs.js";import"./chunk-I66GZJ75-CTCf_Yo_.js";import"./chunk-NSK5VX7P-DXuNU-Mu.js";import"./chunk-4I5QYGJK-oCn2F9vK.js";import"./chunk-WRU74C26-Bd8DMfNR.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-BZb904aP.js";import"./chunk-2GRJ4B5K-C1lWmTRh.js";import"./chunk-XXDRQBXY-BuE3VzE_.js";import"./chunk-KBJHAD2P-Bzz7Y74X.js";import"./chunk-W5SLKNZC-QUfdueDn.js";import"./chunk-QR6OTTB3-BNSdTOqg.js";import"./chunk-7Z6QIM7H-B15a3hbL.js";import"./chunk-J7OUQ5F2-DcPV9e5n.js";import"./chunk-ZIRB5QZD-C6fEPe3t.js";import{r as t,t as n}from"./chunk-JQJVKLGR-CQyzXM9p.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};